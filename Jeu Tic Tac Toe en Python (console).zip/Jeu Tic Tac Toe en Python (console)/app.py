from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)
board = [""] * 9
current_player = "X"

def check_winner(b):
    wins = [(0,1,2), (3,4,5), (6,7,8), (0,3,6), (1,4,7), (2,5,8), (0,4,8), (2,4,6)]
    for a,b,c in wins:
        if board[a] == board[b] == board[c] != "":
            return board[a]
    return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/game', methods=['GET', 'POST'])
def game():
    global board, current_player
    winner = check_winner(board)
    if request.method == 'POST':
        pos = int(request.form['position'])
        if board[pos] == "" and not winner:
            board[pos] = current_player
            current_player = "O" if current_player == "X" else "X"
            winner = check_winner(board)
    return render_template('game.html', board=board, current_player=current_player, winner=winner)

@app.route('/reset')
def reset():
    global board, current_player
    board = [""] * 9
    current_player = "X"
    return redirect(url_for('game'))

if __name__ == '__main__':
    app.run(debug=True)



